define({
  "name": "api接口",
  "version": "0.1.0",
  "description": "api_doc",
  "title": "api_doc",
  "url": "http://127.0.0.1",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-11-01T03:47:43.019Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
